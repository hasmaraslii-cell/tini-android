# Tını (Android, Kotlin + Jetpack Compose)

## Açmak için
1. Android Studio (Ladybug veya yenisi) ile bu klasörü açın, Gradle senkronizasyonunu bekleyin.
2. Cihaz veya emülatör seçip Run'a basın.

## Yapı
- `Theme.kt`: renkler, Tını işareti, oynat/duraklat ikonu
- `Screens.kt`: 10 sn uyarı kapısı (`DisclaimerGate`), arama ekranı, alt oynatıcı
- `MainViewModel.kt`: arama durumu ve ExoPlayer
- `YouTubeSource.kt`: müzik kaynağı. NewPipe Extractor'ın genel API'sini çağırır. Kaynağı değiştirmek için sadece bu dosya yeterli.

## Yazılımcı için notlar
- **Lisans:** NewPipe Extractor GPLv3'tür. Tını'yı onunla dağıtırsanız Tını'nın da GPLv3 ve kaynak kodunun açık olması gerekir.
- **Sürüm:** `app/build.gradle.kts` içindeki `NewPipeExtractor` sürümünü JitPack'ten güncelleyin. API adları (ör. `thumbnails`, `content`) sürüme göre değişebilir.
- **Kırılganlık:** Kütüphane YouTube sayfalarına bağlıdır, YouTube değiştirdikçe güncellemek gerekir.
- **Yapılmadı:** arka planda çalma (Media3 `MediaSessionService` gerekir), tam ekran oynatıcı, kitaplık, indirme.
- **Uyarı metni:** `Screens.kt` içindeki `DisclaimerGate`.

## Kendi anahtarınla imzalama
1. GitHub Actions'tan `tini-apk-unsigned` artifact'ını indirin (`app-release-unsigned.apk`).
2. Anahtar yoksa oluşturun:
   `keytool -genkeypair -v -keystore tini.jks -alias tini -keyalg RSA -keysize 2048 -validity 10000`
3. Hizalayın ve imzalayın (Android SDK build-tools gerekir):
   ```
   zipalign -v -p 4 app-release-unsigned.apk tini-aligned.apk
   apksigner sign --ks tini.jks --out tini-signed.apk tini-aligned.apk
   apksigner verify tini-signed.apk
   ```
Anahtarı (`tini.jks`) güvenli saklayın; kaybederseniz uygulamayı aynı imzayla güncelleyemezsiniz.
