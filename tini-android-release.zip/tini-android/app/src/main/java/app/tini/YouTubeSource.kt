package app.tini

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Track(
    val title: String,
    val artist: String,
    val url: String,
    val thumb: String?,
)

/**
 * Müzik kaynağı. Burada yalnızca NewPipe Extractor'ın genel API'si çağrılır;
 * sayfa çözümleme işi kütüphanenin kendisindedir. Kaynağı değiştirmek için
 * sadece bu dosyayı değiştirmek yeterli (Track listesi + çalınacak adres).
 *
 * Kütüphane API'si sürümler arasında küçük farklar gösterebilir.
 */
object YouTubeSource {
    private var ready = false

    private fun init() {
        if (!ready) {
            NewPipe.init(DownloaderImpl(OkHttpClient()))
            ready = true
        }
    }

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        init()
        val service = ServiceList.YouTube
        val info = SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(query))
        info.relatedItems
            .filterIsInstance<StreamInfoItem>()
            .map { Track(it.name, it.uploaderName ?: "", it.url, it.thumbnails.firstOrNull()?.url) }
    }

    suspend fun audioUrl(trackUrl: String): String = withContext(Dispatchers.IO) {
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, trackUrl)
        val best = info.audioStreams.maxByOrNull { it.averageBitrate }
            ?: error("Ses akışı bulunamadı")
        best.content
    }
}

/** NewPipe Extractor'ın istediği HTTP istemcisi (kütüphane belgelerindeki örneğe benzer). */
class DownloaderImpl(private val client: OkHttpClient) : Downloader() {
    override fun execute(request: Request): Response {
        val body = request.dataToSend()?.toRequestBody()
        val builder = okhttp3.Request.Builder()
            .url(request.url())
            .method(request.httpMethod(), body)
            .header("User-Agent", USER_AGENT)
        request.headers().forEach { (name, values) ->
            builder.removeHeader(name)
            values.forEach { builder.addHeader(name, it) }
        }
        client.newCall(builder.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("reCaptcha gerekli", request.url())
            return Response(
                r.code,
                r.message,
                r.headers.toMultimap(),
                r.body?.string(),
                r.request.url.toString(),
            )
        }
    }

    private companion object {
        const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"
    }
}
