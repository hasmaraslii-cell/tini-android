package app.tini

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

/** Uygulama her açıldığında çıkar; düğme 10 saniye sonra aktif olur. Metni istediğiniz gibi düzenleyin. */
@Composable
fun DisclaimerGate(onAccept: () -> Unit) {
    var left by rememberSaveable { mutableIntStateOf(10) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        TiniMark(height = 64.dp)
        Spacer(Modifier.height(28.dp))
        Text(
            "Başlamadan önce",
            color = Paper,
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "Tını resmi bir YouTube uygulaması değildir ve YouTube ile bağlantılı değildir. " +
                "Müzikler, açık kaynaklı bir kütüphane aracılığıyla herkese açık YouTube sayfalarından alınır.\n\n" +
                "YouTube Hizmet Şartları'na ve telif haklarına uymak sizin sorumluluğunuzdadır. " +
                "Telifli içerikleri izinsiz indirmeyin veya paylaşmayın.",
            color = Muted,
            fontSize = 16.sp,
            lineHeight = 24.sp,
        )
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = onAccept,
            enabled = left == 0,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Ember,
                contentColor = Ink,
                disabledContainerColor = Surface2,
                disabledContentColor = Muted,
            ),
        ) {
            Text(
                if (left > 0) "Lütfen bekleyin ($left)" else "Anladım, devam et",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .windowInsetsPadding(WindowInsets.systemBars),
    ) {
        Row(
            Modifier.padding(start = 20.dp, top = 16.dp, end = 20.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TiniMark(height = 38.dp)
            Spacer(Modifier.width(10.dp))
            Text("tını", color = Paper, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        }

        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            placeholder = { Text("Şarkı veya sanatçı ara") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Paper,
                unfocusedContainerColor = Paper,
                focusedTextColor = Ink,
                unfocusedTextColor = Ink,
                focusedPlaceholderColor = Color(0xFF6B6560),
                unfocusedPlaceholderColor = Color(0xFF6B6560),
                cursorColor = Ink,
                focusedBorderColor = Ember,
                unfocusedBorderColor = Color.Transparent,
            ),
        )

        vm.error?.let {
            Text(it, color = Ember, fontSize = 14.sp, modifier = Modifier.padding(20.dp, 12.dp))
        }

        Column(Modifier.weight(1f)) {
            when {
                vm.loading -> Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalArrangement = Arrangement.Center,
                ) { CircularProgressIndicator(color = Ember) }

                vm.results.isEmpty() -> Text(
                    "Bir şarkı ya da sanatçı ara",
                    color = Muted,
                    modifier = Modifier.padding(20.dp, 24.dp),
                )

                else -> LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(vm.results) { t -> TrackRow(t) { vm.play(t) } }
                }
            }
        }

        vm.current?.let { MiniPlayer(it, vm.isPlaying) { vm.togglePlay() } }
    }
}

@Composable
private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model = track.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Surface2),
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                color = Paper,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                track.artist,
                color = Muted,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun MiniPlayer(track: Track, playing: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Surface2)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model = track.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(10.dp)),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                color = Paper,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                track.artist,
                color = Muted,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Row(
            Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Ember)
                .clickable(onClick = onToggle),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PlayPauseIcon(playing = playing, color = Ink, size = 22.dp)
        }
    }
}
