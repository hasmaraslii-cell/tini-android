package app.tini

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val Ink = Color(0xFF15131C)
val Surface2 = Color(0xFF2A2636)
val Paper = Color(0xFFF6F1EA)
val Muted = Color(0xFFA29B93)
val Ember = Color(0xFFFF5B3A)

@Composable
fun TiniTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Ember,
            onPrimary = Ink,
            background = Ink,
            surface = Surface2,
            onSurface = Paper,
        ),
        content = content,
    )
}

/** Tını işareti: nokta + iki ses halkası. */
@Composable
fun TiniMark(height: Dp, dot: Color = Ember, arcs: Color = Paper) {
    Canvas(Modifier.size(height * 0.633f, height)) {
        val s = size.height / 120f
        // Orijinal çizim 14..90 x 0..120 alanında; x'ten 14 çıkarılır.
        val cx = 26f * s
        val cy = 60f * s
        drawCircle(dot, radius = 18f * s, center = Offset(cx, cy))
        for (r in listOf(34f, 54f)) {
            drawArc(
                color = arcs,
                startAngle = -50f,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(cx - r * s, cy - r * s),
                size = Size(2 * r * s, 2 * r * s),
                style = Stroke(width = 9f * s, cap = StrokeCap.Round),
            )
        }
    }
}

@Composable
fun PlayPauseIcon(playing: Boolean, color: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        if (playing) {
            drawRect(color, Offset(w * 0.20f, h * 0.12f), Size(w * 0.24f, h * 0.76f))
            drawRect(color, Offset(w * 0.56f, h * 0.12f), Size(w * 0.24f, h * 0.76f))
        } else {
            val p = Path().apply {
                moveTo(w * 0.24f, h * 0.10f)
                lineTo(w * 0.90f, h * 0.50f)
                lineTo(w * 0.24f, h * 0.90f)
                close()
            }
            drawPath(p, color)
        }
    }
}
