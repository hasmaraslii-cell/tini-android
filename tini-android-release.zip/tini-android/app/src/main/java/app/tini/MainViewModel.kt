package app.tini

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    var query by mutableStateOf("")
    var results by mutableStateOf<List<Track>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var current by mutableStateOf<Track?>(null)
    var isPlaying by mutableStateOf(false)

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                this@MainViewModel.isPlaying = isPlaying
            }
        })
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        viewModelScope.launch {
            loading = true
            error = null
            try {
                results = YouTubeSource.search(q)
            } catch (e: Exception) {
                error = "Arama başarısız: ${e.message}"
            } finally {
                loading = false
            }
        }
    }

    fun play(track: Track) {
        current = track
        error = null
        viewModelScope.launch {
            try {
                val url = YouTubeSource.audioUrl(track.url)
                player.setMediaItem(MediaItem.fromUri(url))
                player.prepare()
                player.play()
            } catch (e: Exception) {
                error = "Çalınamadı: ${e.message}"
            }
        }
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    override fun onCleared() {
        player.release()
    }
}
